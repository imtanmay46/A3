#include <arpa/inet.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <pthread.h>
#include <security/pam_appl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#define PORT 8443
#define BACKEND_PORT 443
#define BUFFER_SIZE 4096

SSL_CTX *backend_ctx;

void log_ssl_error(const char *msg) {
  fprintf(stderr, "PROXY ERROR: %s\n", msg);
  ERR_print_errors_fp(stderr);
}

SSL_CTX *create_server_ctx() {
  SSL_CTX *ctx = SSL_CTX_new(TLS_server_method());
  SSL_CTX_use_certificate_file(ctx, "proxy.crt", SSL_FILETYPE_PEM);
  SSL_CTX_use_PrivateKey_file(ctx, "proxy.key", SSL_FILETYPE_PEM);
  SSL_CTX_load_verify_locations(ctx, "ca.crt", NULL);
  return ctx;
}

SSL *connect_backend() {
  int sock = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in addr = {.sin_family = AF_INET,
                             .sin_port = htons(BACKEND_PORT),
                             .sin_addr.s_addr = inet_addr("127.0.0.1")};

  connect(sock, (struct sockaddr *)&addr, sizeof(addr));
  SSL *ssl = SSL_new(backend_ctx);
  SSL_set_fd(ssl, sock);
  SSL_connect(ssl);
  return ssl;
}

void Get_Command_Handler(SSL *client, const char *filename) {
  SSL *backend = connect_backend();
  if (!backend)
    return;

  char path[256];
  snprintf(path, sizeof(path), "/var/www/files/%s", filename);

  struct stat st;
  if (stat(path, &st) == -1) {
    const char *error = "ERROR: File not found CMD_END";
    SSL_write(client, error, strlen(error));
    SSL_shutdown(backend);
    SSL_free(backend);
    return;
  }

  char request[512];
  snprintf(request, sizeof(request),
           "GET /files/%s HTTP/1.1\r\n"
           "Host: localhost\r\n"
           "Connection: close\r\n\r\n",
           filename);

  SSL_write(backend, request, strlen(request));

  char buffer[BUFFER_SIZE];
  int content_length = -1;
  int header_processed = 0;
  int total = 0;

  while (1) {
    int bytes = SSL_read(backend, buffer, sizeof(buffer));
    if (bytes <= 0)
      break;

    if (!header_processed) {
      char *body = strstr(buffer, "\r\n\r\n");
      if (body) {
        header_processed = 1;
        bytes -= (body + 4 - buffer);
        memmove(buffer, body + 4, bytes);
      }
    }

    if (header_processed) {
      SSL_write(client, buffer, bytes);
      total += bytes;
    }
  }

  SSL_write(client, "CMD_END", 7);
  SSL_shutdown(backend);
  SSL_free(backend);
}

void Put_Command_Handler(SSL *client, const char *filename) {
  SSL *backend = connect_backend();
  if (!backend)
    return;

  char request[512];
  snprintf(request, sizeof(request),
           "PUT /files/%s HTTP/1.1\r\n"
           "Host: localhost\r\n"
           "Transfer-Encoding: chunked\r\n\r\n",
           filename);

  SSL_write(backend, request, strlen(request));

  char buffer[BUFFER_SIZE];
  int total = 0;
  int marker_found = 0;

  while (SSL_pending(client) > 0) {
    SSL_read(client, buffer, sizeof(buffer));
  }

  while (!marker_found) {
    int bytes = SSL_read(client, buffer, sizeof(buffer));
    if (bytes <= 0)
      break;

    char *error = memmem(buffer, bytes, "PUT_ERROR CMD_END", 16);
    if (error) {
      SSL_write(client, "PUT_FAILED CMD_END", 18);
      marker_found = 1;
      break;
    }

    char *marker = memmem(buffer, bytes, "PUT_COMPLETE CMD_END", 20);
    if (marker) {
      int data_bytes = marker - buffer;
      if (data_bytes > 0) {
        char chunk[32];
        int len = snprintf(chunk, sizeof(chunk), "%x\r\n", data_bytes);
        SSL_write(backend, chunk, len);
        SSL_write(backend, buffer, data_bytes);
        SSL_write(backend, "\r\n", 2);
      }
      SSL_write(backend, "0\r\n\r\n", 5);
      marker_found = 1;
    } else {
      char chunk[32];
      int len = snprintf(chunk, sizeof(chunk), "%x\r\n", bytes);
      SSL_write(backend, chunk, len);
      SSL_write(backend, buffer, bytes);
      SSL_write(backend, "\r\n", 2);
    }
    total += bytes;
  }

  SSL_shutdown(backend);
  SSL_free(backend);

  while (SSL_pending(client) > 0) {
    SSL_read(client, buffer, sizeof(buffer));
  }
}

void LS_Command_Handler(SSL *client) {
  SSL *backend = connect_backend();
  const char *request =
      "GET /files/ HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n";
  SSL_write(backend, request, strlen(request));

  char buffer[BUFFER_SIZE];
  while (1) {
    int bytes = SSL_read(backend, buffer, sizeof(buffer));
    if (bytes <= 0)
      break;
    SSL_write(client, buffer, bytes);
  }
  SSL_write(client, "CMD_END", 7);
  SSL_shutdown(backend);
  SSL_free(backend);
}

int converse(int num_msg, const struct pam_message **msg,
             struct pam_response **resp, void *appdata) {
  printf("PAM: Conversation handler called\n");
  char *password = (char *)appdata;

  *resp = calloc(num_msg, sizeof(struct pam_response));
  if (!*resp)
    return PAM_BUF_ERR;

  (*resp)[0].resp = strdup(password);
  (*resp)[0].resp_retcode = 0;

  return PAM_SUCCESS;
}

int authenticate(const char *user, const char *pass) {
  printf("PAM: Starting authentication for %s\n", user);
  pam_handle_t *pamh = NULL;
  struct pam_conv conv = {&converse, (void *)pass};

  int ret = pam_start("reverse-proxy", user, &conv, &pamh);
  if (ret != PAM_SUCCESS) {
    fprintf(stderr, "PAM: Start failed: %s\n", pam_strerror(pamh, ret));
    return 0;
  }

  ret = pam_authenticate(pamh, 0);
  printf("PAM: Authentication result: %d (%s)\n", ret, pam_strerror(pamh, ret));

  pam_end(pamh, ret);
  return ret == PAM_SUCCESS;
}

void *Client_Handler(void *arg) {
  SSL *ssl = (SSL *)arg;
  char user[256], pass[256];
  SSL_read(ssl, user, sizeof(user));
  SSL_read(ssl, pass, sizeof(pass));

  if (authenticate(user, pass)) {
    SSL_write(ssl, "AUTH_OK", 7);
    printf("AUTH: Authentication successful\n");

    while (1) {
      char command[256];
      int bytes = SSL_read(ssl, command, sizeof(command));
      if (bytes <= 0)
        break;

      if (strcmp(command, "exit") == 0)
        break;
      else if (strcmp(command, "ls") == 0)
        LS_Command_Handler(ssl);
      else if (strncmp(command, "get ", 4) == 0)
        Get_Command_Handler(ssl, command + 4);
      else if (strncmp(command, "put ", 4) == 0)
        Put_Command_Handler(ssl, command + 4);
      else
        SSL_write(ssl, "ERROR: Invalid command", 22);
    }
  } else {
    SSL_write(ssl, "AUTH_FAIL", 9);
    printf("AUTH: Authentication failed\n");
  }

  SSL_shutdown(ssl);
  SSL_free(ssl);
  return NULL;
}

int main() {
  SSL_CTX *ctx = create_server_ctx();
  backend_ctx = SSL_CTX_new(TLS_client_method());
  SSL_CTX_load_verify_locations(backend_ctx, "ca.crt", NULL);

  int sock = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in addr = {AF_INET, htons(PORT), INADDR_ANY};
  bind(sock, (struct sockaddr *)&addr, sizeof(addr));
  listen(sock, 10);

  while (1) {
    struct sockaddr_in client_addr;
    socklen_t len = sizeof(client_addr);
    int client_fd = accept(sock, (struct sockaddr *)&client_addr, &len);

    SSL *ssl = SSL_new(ctx);
    SSL_set_fd(ssl, client_fd);
    SSL_accept(ssl);

    pthread_t thread;
    pthread_create(&thread, NULL, Client_Handler, ssl);
    pthread_detach(thread);
  }

  SSL_CTX_free(ctx);
  SSL_CTX_free(backend_ctx);
  close(sock);
  return 0;
}
