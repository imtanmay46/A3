#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define PROXY_PORT 8443
#define BUFFER_SIZE 4096

void log_ssl_error(const char *msg) {
  fprintf(stderr, "CLIENT ERROR: %s\n", msg);
  ERR_print_errors_fp(stderr);
}

SSL_CTX *create_ssl_context() {
  SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
  if (!ctx) {
    log_ssl_error("Failed to create SSL context");
    return NULL;
  }

  if (SSL_CTX_load_verify_locations(ctx, "ca.crt", NULL) != 1) {
    log_ssl_error("Failed to load CA certificate");
    SSL_CTX_free(ctx);
    return NULL;
  }
  return ctx;
}

void parse_output(const char *html) {
  const char *ptr = html;
  while ((ptr = strstr(ptr, "<a href=\""))) {
    ptr += 9;
    const char *end = strchr(ptr, '"');
    if (!end)
      break;

    char filename[256];
    int len = end - ptr;
    strncpy(filename, ptr, len);
    filename[len] = '\0';

    if (strcmp(filename, "../") != 0) {
      if (filename[len - 1] == '/')
        filename[len - 1] = '\0';
      printf("%s\n", filename);
    }
    ptr = end;
  }
}

void Get_Command_Handler(SSL *ssl, const char *filename) {
  char buffer[BUFFER_SIZE];
  FILE *file = NULL;
  int total = 0;
  int cmd_end = 0;
  size_t recv_buffer_size = 0;
  char *recv_buffer = malloc(BUFFER_SIZE * 2);

  while (!cmd_end) {
    int bytes = SSL_read(ssl, buffer, sizeof(buffer));
    if (bytes <= 0)
      break;

    memcpy(recv_buffer + recv_buffer_size, buffer, bytes);
    recv_buffer_size += bytes;

    char *marker = memmem(recv_buffer, recv_buffer_size, "CMD_END", 7);
    if (marker) {
      cmd_end = 1;
      int data_size = marker - recv_buffer;

      if (strncmp(recv_buffer, "ERROR:", 6) == 0) {
        printf("%.*s\n", data_size, recv_buffer);
      } else {
        file = fopen(filename, "wb");
        if (file) {
          fwrite(recv_buffer, 1, data_size, file);
          fclose(file);
          printf("Downloaded %d bytes\n", data_size);
        }
      }
      recv_buffer_size = 0;
    }

    if (recv_buffer_size >= BUFFER_SIZE * 2) {
      if (file)
        fwrite(recv_buffer, 1, recv_buffer_size, file);
      recv_buffer_size = 0;
    }
  }

  free(recv_buffer);
}

void Put_Command_Handler(SSL *ssl, const char *filename) {
  FILE *file = fopen(filename, "rb");
  if (!file) {
    const char *error = "PUT_ERROR CMD_END";
    SSL_write(ssl, error, strlen(error));
    printf("Error: Local file not found\n");

    char buffer[BUFFER_SIZE];
    while (SSL_pending(ssl) > 0) {
      SSL_read(ssl, buffer, sizeof(buffer));
    }
    return;
  }

  char buffer[BUFFER_SIZE];
  while (SSL_pending(ssl) > 0) {
    SSL_read(ssl, buffer, sizeof(buffer));
  }

  size_t bytes_read;
  while ((bytes_read = fread(buffer, 1, sizeof(buffer), file))) {
    SSL_write(ssl, buffer, bytes_read);
  }
  fclose(file);

  const char *complete = "PUT_COMPLETE CMD_END";
  SSL_write(ssl, complete, strlen(complete));
}

void LS_Command_Handler(SSL *ssl) {
  char buffer[BUFFER_SIZE];
  char full_response[65536] = {0};
  size_t total = 0;
  int cmd_end = 0;

  while (!cmd_end) {
    int bytes = SSL_read(ssl, buffer, sizeof(buffer));
    if (bytes <= 0)
      break;

    char *marker = memmem(buffer, bytes, "CMD_END", 7);
    if (marker) {
      strncat(full_response, buffer, marker - buffer);
      cmd_end = 1;
    } else {
      strncat(full_response, buffer, bytes);
    }
    total += bytes;
  }

  char *body = strstr(full_response, "\r\n\r\n");
  if (body)
    parse_output(body + 4);
  else
    printf("Invalid directory listing\n");
}

void Command_Handler(SSL *ssl, const char *command) {
  char buffer[BUFFER_SIZE];
  while (SSL_pending(ssl) > 0) {
    SSL_read(ssl, buffer, sizeof(buffer));
  }

  SSL_write(ssl, command, strlen(command) + 1);

  if (strncmp(command, "get ", 4) == 0) {
    Get_Command_Handler(ssl, command + 4);
  } else if (strcmp(command, "ls") == 0) {
    LS_Command_Handler(ssl);
  } else if (strncmp(command, "put ", 4) == 0) {
    Put_Command_Handler(ssl, command + 4);
  }
}

int main() {
  SSL_CTX *ctx = create_ssl_context();
  int sock = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in addr = {.sin_family = AF_INET,
                             .sin_port = htons(PROXY_PORT),
                             .sin_addr.s_addr = inet_addr("127.0.0.1")};

  connect(sock, (struct sockaddr *)&addr, sizeof(addr));
  SSL *ssl = SSL_new(ctx);
  SSL_set_fd(ssl, sock);
  SSL_connect(ssl);

  char user[256], pass[256];
  printf("Username: ");
  fgets(user, sizeof(user), stdin);
  user[strcspn(user, "\n")] = '\0';
  printf("Password: ");
  fgets(pass, sizeof(pass), stdin);
  pass[strcspn(pass, "\n")] = '\0';

  printf("CLIENT: Sending credentials...\n");
  SSL_write(ssl, user, strlen(user) + 1);
  SSL_write(ssl, pass, strlen(pass) + 1);

  char response[10];
  SSL_read(ssl, response, sizeof(response));
  printf("CLIENT: Auth response: %s\n", response);

  if (strcmp(response, "AUTH_OK") != 0) {
    printf("CLIENT: Authentication failed\n");
    SSL_shutdown(ssl);
    SSL_free(ssl);
    close(sock);
    SSL_CTX_free(ctx);
    return 0;
  }

  while (1) {
    printf("HTTPS SERVER> ");
    char command[256];
    fgets(command, sizeof(command), stdin);
    command[strcspn(command, "\n")] = '\0';

    if (strcmp(command, "exit") == 0)
      break;
    Command_Handler(ssl, command);
  }

  SSL_shutdown(ssl);
  SSL_free(ssl);
  close(sock);
  SSL_CTX_free(ctx);
  return 0;
}